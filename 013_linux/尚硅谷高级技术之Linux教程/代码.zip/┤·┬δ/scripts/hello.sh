#!/bin/bash
echo "hello, world"
echo "hello, $1"
