#!/bin/bash

filename="$1"_log_$(date +%s)
echo $filename
