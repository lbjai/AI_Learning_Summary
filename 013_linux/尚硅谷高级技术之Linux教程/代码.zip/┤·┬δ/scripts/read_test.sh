#!/bin/bash

read -t 10 -p "请输入您的芳名：" name
echo "welcome, $name"
